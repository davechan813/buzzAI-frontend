## Introduction
This project belongs to vuSearch Inc.

Authors: Masaki Nakada, Zhibang Chen, Jiayu Guo, Lawerence xu, Haejin Jo, Evan Yang.

Contact: davechan813@gmail.com

## To run
`npm install`

`npm start`
